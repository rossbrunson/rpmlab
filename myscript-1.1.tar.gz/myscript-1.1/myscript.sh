# Script by Ross Brunson, Technical Architect, A Cloud Guru.

echo "CONGRATULATIONS! You have succeeded in building, installing and executing the myscript package!"
